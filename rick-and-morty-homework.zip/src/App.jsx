import React, { useState } from "react";
import { Routes, Route, Link } from "react-router-dom";
import CharacterList from "./CharacterList";
import CharacterDetail from "./CharacterDetail";
import Favorites from "./Favorites";
import "./App.css";

const App = () => {
  const [favorites, setFavorites] = useState([]);

  const addFavorite = (char) => {
    if (!favorites.find((f) => f.id === char.id)) {
      setFavorites([...favorites, char]);
    }
  };

  const removeFavorite = (id) => {
    setFavorites(favorites.filter((f) => f.id !== id));
  };

  return (
    <div className="container">
      <h1>Rick and Morty Explorer</h1>
      <nav>
        <Link to="/">Home</Link>
        <Link to="/favorites">Favorites ({favorites.length})</Link>
      </nav>
      <Routes>
        <Route path="/" element={<CharacterList addFavorite={addFavorite} />} />
        <Route path="/character/:id" element={<CharacterDetail />} />
        <Route
          path="/favorites"
          element={<Favorites favorites={favorites} removeFavorite={removeFavorite} />}
        />
      </Routes>
    </div>
  );
};

export default App;