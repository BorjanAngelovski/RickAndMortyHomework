import React from "react";
import { Link } from "react-router-dom";

const Favorites = ({ favorites, removeFavorite }) => {
  return (
    <div>
      <h2>Favorites</h2>
      <ul>
        {favorites.length === 0 ? (
          <p>No favorites added.</p>
        ) : (
          favorites.map((char) => (
            <li key={char.id}>
              <Link to={`/character/${char.id}`}>{char.name}</Link>
              <button onClick={() => removeFavorite(char.id)}>Remove</button>
            </li>
          ))
        )}
      </ul>
    </div>
  );
};

export default Favorites;