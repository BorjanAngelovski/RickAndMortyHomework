import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";

const CharacterList = ({ addFavorite }) => {
  const [characters, setCharacters] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");

  useEffect(() => {
    fetch("https://rickandmortyapi.com/api/character")
      .then((res) => res.json())
      .then((data) => setCharacters(data.results || []));
  }, []);

  const handleSearch = (e) => {
    const value = e.target.value;
    setSearchTerm(value);

    if (value.trim() === "") {
      fetch("https://rickandmortyapi.com/api/character")
        .then((res) => res.json())
        .then((data) => setCharacters(data.results || []));
      return;
    }

    fetch(`https://rickandmortyapi.com/api/character?name=${value}`)
      .then((res) => {
        if (!res.ok) throw new Error("No results");
        return res.json();
      })
      .then((data) => setCharacters(data.results || []))
      .catch(() => setCharacters([]));
  };

  return (
    <div>
      <input
        type="text"
        placeholder="Search characters"
        value={searchTerm}
        onChange={handleSearch}
      />
      <ul>
        {characters.map((char) => (
          <li key={char.id}>
            <Link to={`/character/${char.id}`}>{char.name}</Link>
            <button onClick={() => addFavorite(char)}>❤️</button>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default CharacterList;